**********************************************************************
NOTICE:

This code is now in the public domain.  The Stanford Office of 
Technology Licensing has removed all licensing restrictions.

**********************************************************************

KLT
An implementation of the Kanade-Lucas-Tomasi feature tracker

Version 1.3.4

Authors: Stan Birchfield
         stb@clemson.edu	

         Thorsten Thormaehlen
         thormae@tnt.uni-hannover.de
         (implemented affine code)

         Thanks to many others for various bug fixes.
 
Date: August   30, A.D. 2007
      May      10, A.D. 2007
      March    28, A.D. 2006
      November 21, A.D. 2005
      August   17, A.D. 2005
      June     16, A.D. 2004
      October   7, A.D. 1998

The code can be obtained from http://www.ces.clemson.edu/~stb/klt
(alternatively http://www.vision.stanford.edu/~birch/klt),
where the official manuals reside.  For your convenience, unofficial 
manuals have been placed in the current subdirectory 'doc'.

